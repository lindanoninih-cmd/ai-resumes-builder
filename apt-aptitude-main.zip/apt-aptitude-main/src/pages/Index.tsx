import { useState } from 'react';
import { ResumeProvider } from '@/contexts/ResumeContext';
import { Header } from '@/components/Header';
import { HeroSection } from '@/components/HeroSection';
import { FeaturesSection } from '@/components/FeaturesSection';
import { TemplatesSection } from '@/components/TemplatesSection';
import { ResumeBuilder } from '@/components/ResumeBuilder';
import { Footer } from '@/components/Footer';

const Index = () => {
  const [showBuilder, setShowBuilder] = useState(false);

  return (
    <ResumeProvider>
      <div className="min-h-screen bg-background">
        <Header onGetStarted={() => setShowBuilder(true)} />
        
        {!showBuilder ? (
          <>
            <HeroSection onGetStarted={() => setShowBuilder(true)} />
            <FeaturesSection />
            <TemplatesSection onGetStarted={() => setShowBuilder(true)} />
          </>
        ) : (
          <ResumeBuilder />
        )}
        
        <Footer />
      </div>
    </ResumeProvider>
  );
};

export default Index;
