import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Badge } from '@/components/ui/badge';
import { Wrench, Plus, X, Sparkles } from 'lucide-react';
import { Skill } from '@/types/resume';
import { useState } from 'react';

const skillCategories = [
  'Programming Languages',
  'Frameworks & Libraries',
  'Databases',
  'Cloud & DevOps',
  'Tools & Software',
  'Soft Skills',
  'Languages',
  'Other',
];

const skillLevels = [
  { value: 'beginner', label: 'Beginner' },
  { value: 'intermediate', label: 'Intermediate' },
  { value: 'advanced', label: 'Advanced' },
  { value: 'expert', label: 'Expert' },
];

export function SkillsForm() {
  const { resumeData, setResumeData } = useResume();
  const { skills } = resumeData;
  const [newSkill, setNewSkill] = useState({
    name: '',
    level: 'intermediate' as Skill['level'],
    category: 'Programming Languages',
  });

  const addSkill = () => {
    if (!newSkill.name.trim()) return;
    
    const skill: Skill = {
      id: Date.now().toString(),
      ...newSkill,
    };
    
    setResumeData((prev) => ({
      ...prev,
      skills: [...prev.skills, skill],
    }));
    
    setNewSkill({
      name: '',
      level: 'intermediate',
      category: newSkill.category,
    });
  };

  const removeSkill = (id: string) => {
    setResumeData((prev) => ({
      ...prev,
      skills: prev.skills.filter((s) => s.id !== id),
    }));
  };

  const groupedSkills = skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, Skill[]>);

  const getLevelColor = (level: Skill['level']) => {
    switch (level) {
      case 'beginner':
        return 'bg-muted text-muted-foreground';
      case 'intermediate':
        return 'bg-accent text-accent-foreground';
      case 'advanced':
        return 'bg-primary/20 text-primary';
      case 'expert':
        return 'bg-primary text-primary-foreground';
      default:
        return 'bg-muted text-muted-foreground';
    }
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Wrench className="h-5 w-5 text-primary" />
          Skills
        </CardTitle>
        <CardDescription>
          Add your technical and soft skills with proficiency levels
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Add new skill */}
        <div className="rounded-lg border border-border bg-secondary/20 p-4 space-y-4">
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2 md:col-span-2">
              <Label>Skill Name</Label>
              <Input
                placeholder="e.g., Python, React, Leadership"
                value={newSkill.name}
                onChange={(e) =>
                  setNewSkill((prev) => ({ ...prev, name: e.target.value }))
                }
                onKeyPress={(e) => e.key === 'Enter' && addSkill()}
              />
            </div>

            <div className="space-y-2">
              <Label>Category</Label>
              <Select
                value={newSkill.category}
                onValueChange={(value) =>
                  setNewSkill((prev) => ({ ...prev, category: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {skillCategories.map((cat) => (
                    <SelectItem key={cat} value={cat}>
                      {cat}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label>Level</Label>
              <Select
                value={newSkill.level}
                onValueChange={(value: Skill['level']) =>
                  setNewSkill((prev) => ({ ...prev, level: value }))
                }
              >
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {skillLevels.map((level) => (
                    <SelectItem key={level.value} value={level.value}>
                      {level.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          <Button onClick={addSkill} className="w-full gap-2">
            <Plus className="h-4 w-4" />
            Add Skill
          </Button>
        </div>

        {/* Display skills by category */}
        {Object.entries(groupedSkills).map(([category, categorySkills]) => (
          <div key={category} className="space-y-3">
            <h4 className="text-sm font-semibold text-muted-foreground">
              {category}
            </h4>
            <div className="flex flex-wrap gap-2">
              {categorySkills.map((skill) => (
                <Badge
                  key={skill.id}
                  variant="secondary"
                  className={`gap-1 pr-1 ${getLevelColor(skill.level)}`}
                >
                  {skill.name}
                  <button
                    onClick={() => removeSkill(skill.id)}
                    className="ml-1 rounded-full p-0.5 hover:bg-foreground/10"
                  >
                    <X className="h-3 w-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>
        ))}

        {skills.length === 0 && (
          <div className="text-center py-8 text-muted-foreground">
            <Sparkles className="h-8 w-8 mx-auto mb-2 opacity-50" />
            <p>No skills added yet. Start by adding your key skills above.</p>
          </div>
        )}
      </CardContent>
    </Card>
  );
}
