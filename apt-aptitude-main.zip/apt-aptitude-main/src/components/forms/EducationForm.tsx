import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { GraduationCap, Plus, Trash2, GripVertical } from 'lucide-react';
import { Education } from '@/types/resume';

export function EducationForm() {
  const { resumeData, setResumeData } = useResume();
  const { education } = resumeData;

  const addEducation = () => {
    const newEducation: Education = {
      id: Date.now().toString(),
      institution: '',
      degree: '',
      field: '',
      location: '',
      startDate: '',
      endDate: '',
      gpa: '',
    };
    setResumeData((prev) => ({
      ...prev,
      education: [...prev.education, newEducation],
    }));
  };

  const updateEducation = (id: string, field: string, value: string) => {
    setResumeData((prev) => ({
      ...prev,
      education: prev.education.map((edu) =>
        edu.id === id ? { ...edu, [field]: value } : edu
      ),
    }));
  };

  const removeEducation = (id: string) => {
    setResumeData((prev) => ({
      ...prev,
      education: prev.education.filter((edu) => edu.id !== id),
    }));
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <GraduationCap className="h-5 w-5 text-primary" />
          Education
        </CardTitle>
        <CardDescription>
          Add your educational background
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {education.map((edu, index) => (
          <div
            key={edu.id}
            className="relative rounded-lg border border-border bg-secondary/20 p-4 space-y-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                <span className="text-sm font-medium text-muted-foreground">
                  Education {index + 1}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeEducation(edu.id)}
                className="h-8 w-8 text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Institution *</Label>
                <Input
                  placeholder="Massachusetts Institute of Technology"
                  value={edu.institution}
                  onChange={(e) =>
                    updateEducation(edu.id, 'institution', e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Degree *</Label>
                <Input
                  placeholder="Bachelor of Science"
                  value={edu.degree}
                  onChange={(e) =>
                    updateEducation(edu.id, 'degree', e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Field of Study *</Label>
                <Input
                  placeholder="Computer Science"
                  value={edu.field}
                  onChange={(e) =>
                    updateEducation(edu.id, 'field', e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Location</Label>
                <Input
                  placeholder="Cambridge, MA"
                  value={edu.location}
                  onChange={(e) =>
                    updateEducation(edu.id, 'location', e.target.value)
                  }
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input
                    type="month"
                    value={edu.startDate}
                    onChange={(e) =>
                      updateEducation(edu.id, 'startDate', e.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Date</Label>
                  <Input
                    type="month"
                    value={edu.endDate}
                    onChange={(e) =>
                      updateEducation(edu.id, 'endDate', e.target.value)
                    }
                  />
                </div>
              </div>

              <div className="space-y-2">
                <Label>GPA (Optional)</Label>
                <Input
                  placeholder="3.8/4.0"
                  value={edu.gpa}
                  onChange={(e) =>
                    updateEducation(edu.id, 'gpa', e.target.value)
                  }
                />
              </div>
            </div>
          </div>
        ))}

        <Button
          variant="outline"
          onClick={addEducation}
          className="w-full gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Education
        </Button>
      </CardContent>
    </Card>
  );
}
