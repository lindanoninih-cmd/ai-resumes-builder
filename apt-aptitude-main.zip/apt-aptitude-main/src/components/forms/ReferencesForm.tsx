import { useState } from 'react';
import { useResume } from '@/contexts/ResumeContext';
import { Reference } from '@/types/resume';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Plus, Trash2, Users } from 'lucide-react';

export function ReferencesForm() {
  const { resumeData, setResumeData } = useResume();
  const [editingId, setEditingId] = useState<string | null>(null);

  const addReference = () => {
    const newReference: Reference = {
      id: crypto.randomUUID(),
      name: '',
      title: '',
      company: '',
      email: '',
      phone: '',
      relationship: '',
    };
    setResumeData(prev => ({
      ...prev,
      references: [...prev.references, newReference],
    }));
    setEditingId(newReference.id);
  };

  const updateReference = (id: string, field: keyof Reference, value: string) => {
    setResumeData(prev => ({
      ...prev,
      references: prev.references.map(ref =>
        ref.id === id ? { ...ref, [field]: value } : ref
      ),
    }));
  };

  const removeReference = (id: string) => {
    setResumeData(prev => ({
      ...prev,
      references: prev.references.filter(ref => ref.id !== id),
    }));
    if (editingId === id) {
      setEditingId(null);
    }
  };

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Users className="h-5 w-5 text-primary" />
          References
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <p className="text-sm text-muted-foreground">
          Add professional references who can speak to your qualifications and work ethic.
        </p>

        {resumeData.references.map((reference) => (
          <Card key={reference.id} className="border-muted">
            <CardContent className="pt-4">
              <div className="flex justify-between items-start mb-4">
                <h4 className="font-medium">
                  {reference.name || 'New Reference'}
                </h4>
                <Button
                  variant="ghost"
                  size="icon"
                  onClick={() => removeReference(reference.id)}
                  className="text-destructive hover:text-destructive"
                >
                  <Trash2 className="h-4 w-4" />
                </Button>
              </div>

              <div className="grid gap-4">
                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`name-${reference.id}`}>Full Name *</Label>
                    <Input
                      id={`name-${reference.id}`}
                      value={reference.name}
                      onChange={(e) => updateReference(reference.id, 'name', e.target.value)}
                      placeholder="John Smith"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`title-${reference.id}`}>Job Title *</Label>
                    <Input
                      id={`title-${reference.id}`}
                      value={reference.title}
                      onChange={(e) => updateReference(reference.id, 'title', e.target.value)}
                      placeholder="Senior Manager"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`company-${reference.id}`}>Company *</Label>
                    <Input
                      id={`company-${reference.id}`}
                      value={reference.company}
                      onChange={(e) => updateReference(reference.id, 'company', e.target.value)}
                      placeholder="ABC Corporation"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`relationship-${reference.id}`}>Relationship *</Label>
                    <Input
                      id={`relationship-${reference.id}`}
                      value={reference.relationship}
                      onChange={(e) => updateReference(reference.id, 'relationship', e.target.value)}
                      placeholder="Former Supervisor"
                    />
                  </div>
                </div>

                <div className="grid sm:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor={`email-${reference.id}`}>Email *</Label>
                    <Input
                      id={`email-${reference.id}`}
                      type="email"
                      value={reference.email}
                      onChange={(e) => updateReference(reference.id, 'email', e.target.value)}
                      placeholder="john.smith@example.com"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor={`phone-${reference.id}`}>Phone (Optional)</Label>
                    <Input
                      id={`phone-${reference.id}`}
                      type="tel"
                      value={reference.phone || ''}
                      onChange={(e) => updateReference(reference.id, 'phone', e.target.value)}
                      placeholder="+1 (555) 123-4567"
                    />
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}

        <Button
          type="button"
          variant="outline"
          onClick={addReference}
          className="w-full gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Reference
        </Button>

        <p className="text-xs text-muted-foreground mt-4">
          Tip: It's best to have 2-3 professional references. Make sure to ask for permission before listing someone as a reference.
        </p>
      </CardContent>
    </Card>
  );
}
