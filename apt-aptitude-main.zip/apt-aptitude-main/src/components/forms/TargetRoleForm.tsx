import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Target, FileText } from 'lucide-react';

const industries = [
  'Technology',
  'Healthcare',
  'Finance & Banking',
  'Consulting',
  'Manufacturing',
  'Retail & E-commerce',
  'Education',
  'Marketing & Advertising',
  'Media & Entertainment',
  'Government',
  'Non-profit',
  'Other',
];

export function TargetRoleForm() {
  const { resumeData, setResumeData, jobDescription, setJobDescription } = useResume();

  const updateField = (field: string, value: string) => {
    setResumeData((prev) => ({
      ...prev,
      [field]: value,
    }));
  };

  return (
    <div className="space-y-6">
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Target Role & Industry
          </CardTitle>
          <CardDescription>
            Help us tailor your resume with industry-specific keywords
          </CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid gap-4 md:grid-cols-2">
            <div className="space-y-2">
              <Label htmlFor="targetRole">Target Job Title</Label>
              <Input
                id="targetRole"
                placeholder="e.g., Senior Software Engineer"
                value={resumeData.targetRole}
                onChange={(e) => updateField('targetRole', e.target.value)}
              />
            </div>

            <div className="space-y-2">
              <Label>Target Industry</Label>
              <Select
                value={resumeData.targetIndustry}
                onValueChange={(value) => updateField('targetIndustry', value)}
              >
                <SelectTrigger>
                  <SelectValue placeholder="Select an industry" />
                </SelectTrigger>
                <SelectContent>
                  {industries.map((industry) => (
                    <SelectItem key={industry} value={industry}>
                      {industry}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <FileText className="h-5 w-5 text-primary" />
            Job Description (Optional)
          </CardTitle>
          <CardDescription>
            Paste a job description to match your resume to specific requirements
          </CardDescription>
        </CardHeader>
        <CardContent>
          <Textarea
            placeholder="Paste the job description here to get keyword matching analysis and tailored suggestions..."
            value={jobDescription}
            onChange={(e) => setJobDescription(e.target.value)}
            rows={8}
            className="resize-none"
          />
          <p className="mt-2 text-xs text-muted-foreground">
            Our AI will analyze the job description and suggest ways to optimize your resume for ATS systems
          </p>
        </CardContent>
      </Card>
    </div>
  );
}
