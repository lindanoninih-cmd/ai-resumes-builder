import { useState } from 'react';
import { useResume } from '@/contexts/ResumeContext';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Checkbox } from '@/components/ui/checkbox';
import { Briefcase, Plus, Trash2, GripVertical, Sparkles } from 'lucide-react';
import { Experience } from '@/types/resume';

export function ExperienceForm() {
  const { resumeData, setResumeData } = useResume();
  const { experiences } = resumeData;

  const addExperience = () => {
    const newExperience: Experience = {
      id: Date.now().toString(),
      company: '',
      position: '',
      location: '',
      startDate: '',
      endDate: '',
      current: false,
      description: '',
      achievements: [''],
    };
    setResumeData((prev) => ({
      ...prev,
      experiences: [...prev.experiences, newExperience],
    }));
  };

  const updateExperience = (id: string, field: string, value: any) => {
    setResumeData((prev) => ({
      ...prev,
      experiences: prev.experiences.map((exp) =>
        exp.id === id ? { ...exp, [field]: value } : exp
      ),
    }));
  };

  const removeExperience = (id: string) => {
    setResumeData((prev) => ({
      ...prev,
      experiences: prev.experiences.filter((exp) => exp.id !== id),
    }));
  };

  const addAchievement = (expId: string) => {
    setResumeData((prev) => ({
      ...prev,
      experiences: prev.experiences.map((exp) =>
        exp.id === expId
          ? { ...exp, achievements: [...exp.achievements, ''] }
          : exp
      ),
    }));
  };

  const updateAchievement = (expId: string, index: number, value: string) => {
    setResumeData((prev) => ({
      ...prev,
      experiences: prev.experiences.map((exp) =>
        exp.id === expId
          ? {
              ...exp,
              achievements: exp.achievements.map((a, i) =>
                i === index ? value : a
              ),
            }
          : exp
      ),
    }));
  };

  const removeAchievement = (expId: string, index: number) => {
    setResumeData((prev) => ({
      ...prev,
      experiences: prev.experiences.map((exp) =>
        exp.id === expId
          ? {
              ...exp,
              achievements: exp.achievements.filter((_, i) => i !== index),
            }
          : exp
      ),
    }));
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Briefcase className="h-5 w-5 text-primary" />
          Work Experience
        </CardTitle>
        <CardDescription>
          Add your professional experience, starting with the most recent
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {experiences.map((exp, index) => (
          <div
            key={exp.id}
            className="relative rounded-lg border border-border bg-secondary/20 p-4 space-y-4"
          >
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2">
                <GripVertical className="h-5 w-5 text-muted-foreground cursor-grab" />
                <span className="text-sm font-medium text-muted-foreground">
                  Position {index + 1}
                </span>
              </div>
              <Button
                variant="ghost"
                size="icon"
                onClick={() => removeExperience(exp.id)}
                className="h-8 w-8 text-destructive hover:text-destructive"
              >
                <Trash2 className="h-4 w-4" />
              </Button>
            </div>

            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label>Job Title *</Label>
                <Input
                  placeholder="Senior Software Engineer"
                  value={exp.position}
                  onChange={(e) =>
                    updateExperience(exp.id, 'position', e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Company *</Label>
                <Input
                  placeholder="Google"
                  value={exp.company}
                  onChange={(e) =>
                    updateExperience(exp.id, 'company', e.target.value)
                  }
                />
              </div>

              <div className="space-y-2">
                <Label>Location</Label>
                <Input
                  placeholder="San Francisco, CA"
                  value={exp.location}
                  onChange={(e) =>
                    updateExperience(exp.id, 'location', e.target.value)
                  }
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div className="space-y-2">
                  <Label>Start Date</Label>
                  <Input
                    type="month"
                    value={exp.startDate}
                    onChange={(e) =>
                      updateExperience(exp.id, 'startDate', e.target.value)
                    }
                  />
                </div>
                <div className="space-y-2">
                  <Label>End Date</Label>
                  <Input
                    type="month"
                    value={exp.endDate}
                    disabled={exp.current}
                    onChange={(e) =>
                      updateExperience(exp.id, 'endDate', e.target.value)
                    }
                  />
                </div>
              </div>
            </div>

            <div className="flex items-center space-x-2">
              <Checkbox
                id={`current-${exp.id}`}
                checked={exp.current}
                onCheckedChange={(checked) =>
                  updateExperience(exp.id, 'current', checked)
                }
              />
              <Label htmlFor={`current-${exp.id}`} className="text-sm font-normal">
                I currently work here
              </Label>
            </div>

            <div className="space-y-2">
              <Label>Job Description</Label>
              <Textarea
                placeholder="Describe your role and responsibilities..."
                value={exp.description}
                onChange={(e) =>
                  updateExperience(exp.id, 'description', e.target.value)
                }
                rows={3}
              />
            </div>

            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <Label>Key Achievements</Label>
                <Button
                  variant="ghost"
                  size="sm"
                  onClick={() => addAchievement(exp.id)}
                  className="h-8 gap-1 text-primary"
                >
                  <Plus className="h-3 w-3" />
                  Add Achievement
                </Button>
              </div>
              {exp.achievements.map((achievement, aIndex) => (
                <div key={aIndex} className="flex items-center gap-2">
                  <Input
                    placeholder="• Increased team productivity by 40%..."
                    value={achievement}
                    onChange={(e) =>
                      updateAchievement(exp.id, aIndex, e.target.value)
                    }
                  />
                  {exp.achievements.length > 1 && (
                    <Button
                      variant="ghost"
                      size="icon"
                      onClick={() => removeAchievement(exp.id, aIndex)}
                      className="h-8 w-8 shrink-0"
                    >
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  )}
                </div>
              ))}
            </div>
          </div>
        ))}

        <Button
          variant="outline"
          onClick={addExperience}
          className="w-full gap-2"
        >
          <Plus className="h-4 w-4" />
          Add Work Experience
        </Button>
      </CardContent>
    </Card>
  );
}
