import { useResume } from '@/contexts/ResumeContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Button } from '@/components/ui/button';
import { Shield, CheckCircle2, AlertTriangle, XCircle, Sparkles, RefreshCw } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState, useEffect } from 'react';

export function ATSScoreCard() {
  const { resumeData, atsScore, setAtsScore } = useResume();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeResume = () => {
    setIsAnalyzing(true);
    
    // Simulate ATS analysis
    setTimeout(() => {
      const hasName = !!resumeData.personalInfo.fullName;
      const hasEmail = !!resumeData.personalInfo.email;
      const hasPhone = !!resumeData.personalInfo.phone;
      const hasSummary = !!resumeData.personalInfo.summary;
      const hasExperience = resumeData.experiences.length > 0;
      const hasEducation = resumeData.education.length > 0;
      const hasSkills = resumeData.skills.length > 0;
      const hasAchievements = resumeData.experiences.some(e => e.achievements.filter(a => a).length > 0);

      const formatting = Math.round(
        ((hasName ? 20 : 0) + (hasEmail ? 20 : 0) + (hasPhone ? 20 : 0) + 
         (hasSummary ? 20 : 0) + (hasExperience ? 20 : 0)) 
      );

      const keywords = Math.round(
        ((hasSkills ? 40 : 0) + (resumeData.skills.length > 5 ? 30 : resumeData.skills.length * 6) + 
         (resumeData.targetRole ? 30 : 0))
      );

      const readability = Math.round(
        ((hasEducation ? 25 : 0) + (hasAchievements ? 35 : 0) + 
         (hasSummary && resumeData.personalInfo.summary!.length > 50 ? 40 : 20))
      );

      const overall = Math.round((formatting * 0.3 + keywords * 0.4 + readability * 0.3));

      const suggestions: string[] = [];
      if (!hasSummary) suggestions.push('Add a professional summary to improve your ATS score');
      if (!hasSkills) suggestions.push('Add relevant skills to match job requirements');
      if (resumeData.skills.length < 5) suggestions.push('Consider adding more skills (aim for 8-12)');
      if (!hasAchievements) suggestions.push('Add quantifiable achievements to your experience');
      if (!resumeData.targetRole) suggestions.push('Specify a target role for better keyword optimization');

      setAtsScore({
        overall,
        formatting,
        keywords,
        readability,
        suggestions,
      });
      setIsAnalyzing(false);
    }, 1500);
  };

  const getScoreColor = (score: number) => {
    if (score >= 80) return 'text-success';
    if (score >= 60) return 'text-warning';
    return 'text-destructive';
  };

  const getScoreIcon = (score: number) => {
    if (score >= 80) return <CheckCircle2 className="h-5 w-5 text-success" />;
    if (score >= 60) return <AlertTriangle className="h-5 w-5 text-warning" />;
    return <XCircle className="h-5 w-5 text-destructive" />;
  };

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Shield className="h-5 w-5 text-primary" />
          ATS Compatibility
        </CardTitle>
        <CardDescription>
          Check how well your resume performs with Applicant Tracking Systems
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!atsScore ? (
          <div className="text-center py-8">
            <Shield className="h-12 w-12 mx-auto mb-4 text-muted-foreground/50" />
            <p className="text-muted-foreground mb-4">
              Analyze your resume for ATS compatibility
            </p>
            <Button onClick={analyzeResume} disabled={isAnalyzing} className="gap-2">
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Analyze Resume
                </>
              )}
            </Button>
          </div>
        ) : (
          <>
            {/* Overall Score */}
            <div className="text-center p-6 rounded-xl bg-gradient-accent">
              <div className={cn('text-5xl font-bold mb-2', getScoreColor(atsScore.overall))}>
                {atsScore.overall}
              </div>
              <p className="text-muted-foreground">Overall ATS Score</p>
            </div>

            {/* Breakdown */}
            <div className="space-y-4">
              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Formatting</span>
                  <span className={getScoreColor(atsScore.formatting)}>{atsScore.formatting}%</span>
                </div>
                <Progress value={atsScore.formatting} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Keywords</span>
                  <span className={getScoreColor(atsScore.keywords)}>{atsScore.keywords}%</span>
                </div>
                <Progress value={atsScore.keywords} className="h-2" />
              </div>

              <div className="space-y-2">
                <div className="flex items-center justify-between text-sm">
                  <span className="font-medium">Readability</span>
                  <span className={getScoreColor(atsScore.readability)}>{atsScore.readability}%</span>
                </div>
                <Progress value={atsScore.readability} className="h-2" />
              </div>
            </div>

            {/* Suggestions */}
            {atsScore.suggestions.length > 0 && (
              <div className="space-y-3">
                <h4 className="font-semibold text-sm">Suggestions</h4>
                <ul className="space-y-2">
                  {atsScore.suggestions.map((suggestion, index) => (
                    <li 
                      key={index}
                      className="flex items-start gap-2 text-sm text-muted-foreground"
                    >
                      <AlertTriangle className="h-4 w-4 shrink-0 text-warning mt-0.5" />
                      {suggestion}
                    </li>
                  ))}
                </ul>
              </div>
            )}

            <Button 
              variant="outline" 
              onClick={analyzeResume} 
              disabled={isAnalyzing}
              className="w-full gap-2"
            >
              <RefreshCw className={cn('h-4 w-4', isAnalyzing && 'animate-spin')} />
              Re-analyze
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
