import { useRef } from 'react';
import { useResume } from '@/contexts/ResumeContext';
import { ModernTemplate } from './templates/ModernTemplate';
import { ClassicTemplate } from './templates/ClassicTemplate';
import { CreativeTemplate } from './templates/CreativeTemplate';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Eye, Download, FileText, FileType, Code } from 'lucide-react';
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from '@/components/ui/dropdown-menu';
import { useToast } from '@/hooks/use-toast';
import html2pdf from 'html2pdf.js';
import { asBlob } from 'html-docx-js-typescript';

export function ResumePreview() {
  const { resumeData, selectedTemplate, customization } = useResume();
  const { toast } = useToast();
  const templateRef = useRef<HTMLDivElement>(null);

  const renderTemplate = () => {
    switch (selectedTemplate) {
      case 'modern':
        return <ModernTemplate data={resumeData} customization={customization} />;
      case 'classic':
        return <ClassicTemplate data={resumeData} customization={customization} />;
      case 'creative':
        return <CreativeTemplate data={resumeData} customization={customization} />;
      default:
        return <ModernTemplate data={resumeData} customization={customization} />;
    }
  };

  const getFileName = () => {
    const name = resumeData.personalInfo.fullName || 'resume';
    return name.replace(/\s+/g, '_').toLowerCase();
  };

  const handleExport = async (format: 'pdf' | 'docx' | 'html') => {
    if (!templateRef.current) return;

    toast({
      title: `Exporting as ${format.toUpperCase()}`,
      description: 'Your resume is being prepared for download...',
    });

    const fileName = getFileName();

    try {
      if (format === 'pdf') {
        const element = templateRef.current;
        const opt = {
          margin: 0,
          filename: `${fileName}.pdf`,
          image: { type: 'jpeg', quality: 0.98 },
          html2canvas: { scale: 2, useCORS: true },
          jsPDF: { unit: 'in', format: 'letter', orientation: 'portrait' }
        };
        await html2pdf().set(opt).from(element).save();
      } else if (format === 'html') {
        const htmlContent = templateRef.current.innerHTML;
        const fullHtml = `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>${resumeData.personalInfo.fullName || 'Resume'}</title>
  <style>
    body { font-family: ${customization.fontFamily}, sans-serif; margin: 0; padding: 20px; }
  </style>
</head>
<body>
${htmlContent}
</body>
</html>`;
        const blob = new Blob([fullHtml], { type: 'text/html' });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${fileName}.html`;
        link.click();
        URL.revokeObjectURL(url);
      } else if (format === 'docx') {
        const htmlContent = templateRef.current.innerHTML;
        const blob = await asBlob(htmlContent) as Blob;
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `${fileName}.docx`;
        link.click();
        URL.revokeObjectURL(url);
      }

      toast({
        title: 'Export Complete',
        description: `Your resume has been downloaded as ${format.toUpperCase()}.`,
      });
    } catch (error) {
      toast({
        title: 'Export Failed',
        description: 'There was an error exporting your resume. Please try again.',
        variant: 'destructive',
      });
    }
  };

  return (
    <Card className="shadow-card sticky top-20">
      <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-4">
        <CardTitle className="flex items-center gap-2">
          <Eye className="h-5 w-5 text-primary" />
          Live Preview
        </CardTitle>
        <DropdownMenu>
          <DropdownMenuTrigger asChild>
            <Button variant="default" size="sm" className="gap-2">
              <Download className="h-4 w-4" />
              Export
            </Button>
          </DropdownMenuTrigger>
          <DropdownMenuContent align="end">
            <DropdownMenuItem onClick={() => handleExport('pdf')}>
              <FileText className="h-4 w-4 mr-2" />
              Export as PDF
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport('docx')}>
              <FileType className="h-4 w-4 mr-2" />
              Export as DOCX
            </DropdownMenuItem>
            <DropdownMenuItem onClick={() => handleExport('html')}>
              <Code className="h-4 w-4 mr-2" />
              Export as HTML
            </DropdownMenuItem>
          </DropdownMenuContent>
        </DropdownMenu>
      </CardHeader>
      <CardContent>
        <div className="overflow-auto max-h-[800px] border border-border rounded-lg">
          <div className="transform scale-[0.5] origin-top-left w-[200%]">
            <div ref={templateRef}>
              {renderTemplate()}
            </div>
          </div>
        </div>
        <p className="text-xs text-muted-foreground text-center mt-3">
          Preview scaled to 50% • Actual size: 8.5" × 11"
        </p>
      </CardContent>
    </Card>
  );
}
