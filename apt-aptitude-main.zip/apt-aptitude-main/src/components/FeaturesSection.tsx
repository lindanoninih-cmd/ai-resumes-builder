import { 
  Sparkles, 
  Target, 
  FileCheck, 
  Download, 
  Lightbulb, 
  RefreshCw,
  Palette,
  Shield,
  Zap
} from 'lucide-react';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

const features = [
  {
    icon: Sparkles,
    title: 'AI Content Generation',
    description: 'Get intelligent suggestions for your professional summary, achievements, and skills based on your industry.',
  },
  {
    icon: Target,
    title: 'Keyword Optimization',
    description: 'Automatically optimize your resume with industry-specific keywords to pass ATS screening.',
  },
  {
    icon: Shield,
    title: 'ATS Compatibility',
    description: 'Real-time ATS scoring ensures your resume gets past automated screening systems.',
  },
  {
    icon: Download,
    title: 'Multiple Export Formats',
    description: 'Export your resume as PDF, DOCX, or HTML - perfect for any application requirement.',
  },
  {
    icon: Lightbulb,
    title: 'Smart Suggestions',
    description: 'Receive personalized recommendations based on your target role and industry.',
  },
  {
    icon: RefreshCw,
    title: 'Feedback Loop',
    description: 'The AI learns from your edits to provide increasingly relevant suggestions.',
  },
  {
    icon: Palette,
    title: 'Custom Templates',
    description: 'Choose from 3 professional templates with full customization options.',
  },
  {
    icon: FileCheck,
    title: 'Job Matching',
    description: 'Compare your resume against job descriptions to maximize your match score.',
  },
  {
    icon: Zap,
    title: 'Instant Preview',
    description: 'See your changes in real-time with our live preview feature.',
  },
];

export function FeaturesSection() {
  return (
    <section id="features" className="py-20 bg-secondary/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-3">
            Everything You Need to <span className="text-gradient">Land Your Dream Job</span>
          </h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Our AI-powered platform provides all the tools you need to create a professional, 
            ATS-optimized resume that stands out from the competition.
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
          {features.map((feature, index) => (
            <Card 
              key={index} 
              className="shadow-card hover:shadow-lg transition-all duration-300 hover:-translate-y-1 bg-card"
            >
              <CardHeader>
                <div className="h-12 w-12 rounded-xl bg-gradient-primary flex items-center justify-center mb-3">
                  <feature.icon className="h-6 w-6 text-primary-foreground" />
                </div>
                <CardTitle className="text-lg">{feature.title}</CardTitle>
              </CardHeader>
              <CardContent>
                <CardDescription className="text-muted-foreground">
                  {feature.description}
                </CardDescription>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
}
