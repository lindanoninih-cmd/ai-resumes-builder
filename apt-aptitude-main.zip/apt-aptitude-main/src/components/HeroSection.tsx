import { useState } from 'react';
import { ArrowRight, CheckCircle2, Sparkles, Zap, Target, FileCheck } from 'lucide-react';
import { Button } from './ui/button';
import { useResume } from '@/contexts/ResumeContext';
import { TemplatesDialog } from './TemplatesDialog';

const features = [
  { icon: Sparkles, text: 'AI-Powered Content Generation' },
  { icon: Target, text: 'ATS-Optimized Formatting' },
  { icon: FileCheck, text: 'Multiple Export Formats' },
];

export function HeroSection({ onGetStarted }: { onGetStarted: () => void }) {
  const [showTemplates, setShowTemplates] = useState(false);
  const { setSelectedTemplate } = useResume();

  const handleSelectTemplate = (templateId: string) => {
    setSelectedTemplate(templateId as 'modern' | 'classic' | 'creative');
    setShowTemplates(false);
    onGetStarted();
  };
  return (
    <section className="relative overflow-hidden bg-gradient-hero py-20 lg:py-32">
      {/* Background decoration */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="absolute -top-40 -right-40 h-80 w-80 rounded-full bg-primary/5 blur-3xl" />
        <div className="absolute -bottom-40 -left-40 h-80 w-80 rounded-full bg-primary/10 blur-3xl" />
      </div>

      <div className="container relative">
        <div className="mx-auto max-w-4xl text-center">
          {/* Badge */}
          <div className="mb-8 inline-flex items-center gap-2 rounded-full bg-accent px-4 py-2 text-sm font-medium text-accent-foreground animate-fade-in">
            <Zap className="h-4 w-4" />
            <span>Powered by Advanced AI</span>
          </div>

          {/* Heading */}
          <h1 className="mb-6 text-4xl font-extrabold tracking-tight sm:text-5xl lg:text-6xl animate-slide-up">
            Create <span className="text-gradient">ATS-Friendly</span> Resumes
            <br />
            That Get You Hired
          </h1>

          {/* Subheading */}
          <p className="mx-auto mb-10 max-w-2xl text-lg text-muted-foreground animate-slide-up" style={{ animationDelay: '100ms' }}>
            Generate professional, tailored resumes in minutes with AI-powered content suggestions, 
            industry-specific keywords, and real-time ATS compatibility scoring.
          </p>

          {/* CTA Buttons */}
          <div className="mb-12 flex flex-col sm:flex-row items-center justify-center gap-4 animate-slide-up" style={{ animationDelay: '200ms' }}>
            <Button variant="hero" size="xl" onClick={onGetStarted} className="gap-2 w-full sm:w-auto">
              Build Your Resume
              <ArrowRight className="h-5 w-5" />
            </Button>
            <Button 
              variant="outline" 
              size="xl" 
              className="w-full sm:w-auto"
              onClick={() => setShowTemplates(true)}
            >
              View Templates
            </Button>
          </div>

          {/* Templates Dialog */}
          <TemplatesDialog 
            open={showTemplates} 
            onOpenChange={setShowTemplates}
            onSelectTemplate={handleSelectTemplate}
          />

          {/* Features */}
          <div className="flex flex-col sm:flex-row items-center justify-center gap-6 text-sm text-muted-foreground animate-fade-in" style={{ animationDelay: '300ms' }}>
            {features.map((feature, index) => (
              <div key={index} className="flex items-center gap-2">
                <feature.icon className="h-5 w-5 text-primary" />
                <span>{feature.text}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Stats */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 max-w-4xl mx-auto animate-fade-in" style={{ animationDelay: '400ms' }}>
          {[
            { value: '50K+', label: 'Resumes Created' },
            { value: '95%', label: 'ATS Pass Rate' },
            { value: '3x', label: 'More Interviews' },
            { value: '4.9/5', label: 'User Rating' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl font-bold text-foreground">{stat.value}</div>
              <div className="text-sm text-muted-foreground">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
