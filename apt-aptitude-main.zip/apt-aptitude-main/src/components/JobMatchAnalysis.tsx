import { useResume } from '@/contexts/ResumeContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Target, CheckCircle2, XCircle, Sparkles, RefreshCw, Lightbulb } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useState } from 'react';

export function JobMatchAnalysis() {
  const { resumeData, jobDescription, jobMatch, setJobMatch } = useResume();
  const [isAnalyzing, setIsAnalyzing] = useState(false);

  const analyzeJobMatch = () => {
    if (!jobDescription.trim()) return;
    
    setIsAnalyzing(true);
    
    // Simulate job match analysis
    setTimeout(() => {
      // Extract keywords from job description (simplified)
      const jdWords = jobDescription.toLowerCase().split(/\s+/);
      const commonKeywords = [
        'javascript', 'react', 'node', 'python', 'java', 'aws', 'docker', 'kubernetes',
        'agile', 'scrum', 'leadership', 'communication', 'teamwork', 'sql', 'nosql',
        'api', 'rest', 'graphql', 'ci/cd', 'git', 'testing', 'typescript', 'html', 'css'
      ];
      
      const jdKeywords = commonKeywords.filter(kw => 
        jdWords.some(word => word.includes(kw))
      );
      
      const userSkills = resumeData.skills.map(s => s.name.toLowerCase());
      const matched = jdKeywords.filter(kw => 
        userSkills.some(skill => skill.includes(kw) || kw.includes(skill))
      );
      const missing = jdKeywords.filter(kw => 
        !userSkills.some(skill => skill.includes(kw) || kw.includes(skill))
      );
      
      const score = jdKeywords.length > 0 
        ? Math.round((matched.length / jdKeywords.length) * 100)
        : 50;

      const suggestions = [
        missing.length > 0 && `Consider adding skills like: ${missing.slice(0, 3).join(', ')}`,
        'Tailor your professional summary to highlight relevant experience',
        'Use similar language/terminology from the job description',
        'Quantify your achievements with metrics where possible',
      ].filter(Boolean) as string[];

      setJobMatch({
        score,
        matchedKeywords: matched,
        missingKeywords: missing,
        suggestions,
      });
      setIsAnalyzing(false);
    }, 2000);
  };

  if (!jobDescription.trim()) {
    return (
      <Card className="shadow-card">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Target className="h-5 w-5 text-primary" />
            Job Match Analysis
          </CardTitle>
          <CardDescription>
            Add a job description to see how well your resume matches
          </CardDescription>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            <Target className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p>Paste a job description in the Target Role section to get match analysis</p>
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Target className="h-5 w-5 text-primary" />
          Job Match Analysis
        </CardTitle>
        <CardDescription>
          See how well your resume matches the job requirements
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {!jobMatch ? (
          <div className="text-center py-4">
            <Button onClick={analyzeJobMatch} disabled={isAnalyzing} className="gap-2">
              {isAnalyzing ? (
                <>
                  <RefreshCw className="h-4 w-4 animate-spin" />
                  Analyzing...
                </>
              ) : (
                <>
                  <Sparkles className="h-4 w-4" />
                  Analyze Match
                </>
              )}
            </Button>
          </div>
        ) : (
          <>
            {/* Match Score */}
            <div className="text-center p-6 rounded-xl bg-gradient-accent">
              <div className={cn(
                'text-5xl font-bold mb-2',
                jobMatch.score >= 70 ? 'text-success' : jobMatch.score >= 50 ? 'text-warning' : 'text-destructive'
              )}>
                {jobMatch.score}%
              </div>
              <p className="text-muted-foreground">Job Match Score</p>
            </div>

            {/* Matched Keywords */}
            {jobMatch.matchedKeywords.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <CheckCircle2 className="h-4 w-4 text-success" />
                  Matched Keywords ({jobMatch.matchedKeywords.length})
                </div>
                <div className="flex flex-wrap gap-1">
                  {jobMatch.matchedKeywords.map((keyword, i) => (
                    <Badge key={i} variant="secondary" className="bg-success/10 text-success">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Missing Keywords */}
            {jobMatch.missingKeywords.length > 0 && (
              <div className="space-y-2">
                <div className="flex items-center gap-2 text-sm font-medium">
                  <XCircle className="h-4 w-4 text-destructive" />
                  Missing Keywords ({jobMatch.missingKeywords.length})
                </div>
                <div className="flex flex-wrap gap-1">
                  {jobMatch.missingKeywords.map((keyword, i) => (
                    <Badge key={i} variant="secondary" className="bg-destructive/10 text-destructive">
                      {keyword}
                    </Badge>
                  ))}
                </div>
              </div>
            )}

            {/* Suggestions */}
            <div className="space-y-2">
              <div className="flex items-center gap-2 text-sm font-medium">
                <Lightbulb className="h-4 w-4 text-warning" />
                Suggestions
              </div>
              <ul className="space-y-2">
                {jobMatch.suggestions.map((suggestion, i) => (
                  <li key={i} className="text-sm text-muted-foreground flex items-start gap-2">
                    <span className="text-primary">•</span>
                    {suggestion}
                  </li>
                ))}
              </ul>
            </div>

            <Button 
              variant="outline" 
              onClick={analyzeJobMatch} 
              disabled={isAnalyzing}
              className="w-full gap-2"
            >
              <RefreshCw className={cn('h-4 w-4', isAnalyzing && 'animate-spin')} />
              Re-analyze
            </Button>
          </>
        )}
      </CardContent>
    </Card>
  );
}
