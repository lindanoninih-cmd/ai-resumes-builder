import { ResumeData, TemplateCustomization } from '@/types/resume';
import { Mail, Phone, MapPin, Linkedin, Globe } from 'lucide-react';

interface TemplateProps {
  data: ResumeData;
  customization: TemplateCustomization;
}

export function ModernTemplate({ data, customization }: TemplateProps) {
  const { personalInfo, experiences, education, skills, projects, certifications, references } = data;

  const formatDate = (date: string) => {
    if (!date) return '';
    const [year, month] = date.split('-');
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${monthNames[parseInt(month) - 1]} ${year}`;
  };

  const groupedSkills = skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof skills>);

  return (
    <div 
      className="resume-modern bg-white p-8 min-h-[1056px] w-[816px] mx-auto shadow-lg"
      style={{ 
        fontFamily: customization.fontFamily,
        fontSize: customization.fontSize === 'small' ? '14px' : customization.fontSize === 'large' ? '18px' : '16px'
      }}
    >
      {/* Header */}
      <header className="mb-6 border-b-2 pb-4" style={{ borderColor: customization.primaryColor }}>
        <h1 
          className="text-3xl font-bold mb-2"
          style={{ color: customization.primaryColor }}
        >
          {personalInfo.fullName || 'Your Name'}
        </h1>
        
        <div className="flex flex-wrap gap-4 text-sm text-gray-600">
          {personalInfo.email && (
            <div className="flex items-center gap-1">
              <Mail className="h-4 w-4" style={{ color: customization.primaryColor }} />
              <span>{personalInfo.email}</span>
            </div>
          )}
          {personalInfo.phone && (
            <div className="flex items-center gap-1">
              <Phone className="h-4 w-4" style={{ color: customization.primaryColor }} />
              <span>{personalInfo.phone}</span>
            </div>
          )}
          {personalInfo.location && (
            <div className="flex items-center gap-1">
              <MapPin className="h-4 w-4" style={{ color: customization.primaryColor }} />
              <span>{personalInfo.location}</span>
            </div>
          )}
          {personalInfo.linkedin && (
            <div className="flex items-center gap-1">
              <Linkedin className="h-4 w-4" style={{ color: customization.primaryColor }} />
              <span>{personalInfo.linkedin}</span>
            </div>
          )}
          {personalInfo.website && (
            <div className="flex items-center gap-1">
              <Globe className="h-4 w-4" style={{ color: customization.primaryColor }} />
              <span>{personalInfo.website}</span>
            </div>
          )}
        </div>
      </header>

      {/* Summary */}
      {personalInfo.summary && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-2 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Professional Summary
          </h2>
          <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
        </section>
      )}

      {/* Experience */}
      {experiences.length > 0 && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Work Experience
          </h2>
          <div className="space-y-4">
            {experiences.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-start mb-1">
                  <div>
                    <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                    <p className="text-gray-600">{exp.company}{exp.location && ` • ${exp.location}`}</p>
                  </div>
                  <span className="text-sm text-gray-500">
                    {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                  </span>
                </div>
                {exp.description && (
                  <p className="text-gray-700 text-sm mb-2">{exp.description}</p>
                )}
                {exp.achievements.filter(a => a).length > 0 && (
                  <ul className="list-disc list-inside text-sm text-gray-700 space-y-1">
                    {exp.achievements.filter(a => a).map((achievement, i) => (
                      <li key={i}>{achievement}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Education */}
      {education.length > 0 && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Education
          </h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id} className="flex justify-between items-start">
                <div>
                  <h3 className="font-semibold text-gray-900">{edu.degree} in {edu.field}</h3>
                  <p className="text-gray-600">{edu.institution}{edu.location && ` • ${edu.location}`}</p>
                  {edu.gpa && <p className="text-sm text-gray-500">GPA: {edu.gpa}</p>}
                </div>
                <span className="text-sm text-gray-500">
                  {formatDate(edu.startDate)} - {formatDate(edu.endDate)}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Skills
          </h2>
          <div className="space-y-2">
            {Object.entries(groupedSkills).map(([category, categorySkills]) => (
              <div key={category} className="flex flex-wrap gap-x-1">
                <span className="font-medium text-gray-700">{category}:</span>
                <span className="text-gray-600">
                  {categorySkills.map(s => s.name).join(', ')}
                </span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Projects
          </h2>
          <div className="space-y-3">
            {projects.map((project) => (
              <div key={project.id}>
                <h3 className="font-semibold text-gray-900">{project.name}</h3>
                <p className="text-gray-700 text-sm">{project.description}</p>
                {project.technologies.length > 0 && (
                  <p className="text-sm text-gray-500 mt-1">
                    Technologies: {project.technologies.join(', ')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Certifications */}
      {certifications.length > 0 && (
        <section className="mb-6">
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            Certifications
          </h2>
          <div className="space-y-2">
            {certifications.map((cert) => (
              <div key={cert.id} className="flex justify-between items-center">
                <div>
                  <span className="font-medium text-gray-900">{cert.name}</span>
                  <span className="text-gray-600"> • {cert.issuer}</span>
                </div>
                <span className="text-sm text-gray-500">{formatDate(cert.date)}</span>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* References */}
      {references.length > 0 && (
        <section>
          <h2 
            className="text-lg font-semibold mb-3 uppercase tracking-wide"
            style={{ color: customization.primaryColor }}
          >
            References
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {references.map((ref) => (
              <div key={ref.id} className="text-sm">
                <p className="font-semibold text-gray-900">{ref.name}</p>
                <p className="text-gray-700">{ref.title}</p>
                <p className="text-gray-600">{ref.company}</p>
                <p className="text-gray-500">{ref.relationship}</p>
                <p className="text-gray-600 mt-1">{ref.email}</p>
                {ref.phone && <p className="text-gray-600">{ref.phone}</p>}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
