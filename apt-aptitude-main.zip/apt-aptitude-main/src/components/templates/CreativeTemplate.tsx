import { ResumeData, TemplateCustomization } from '@/types/resume';
import { Mail, Phone, MapPin, Linkedin, Globe, Award, Briefcase, GraduationCap, Code, Star, Users } from 'lucide-react';

interface TemplateProps {
  data: ResumeData;
  customization: TemplateCustomization;
}

export function CreativeTemplate({ data, customization }: TemplateProps) {
  const { personalInfo, experiences, education, skills, projects, certifications, references } = data;

  const formatDate = (date: string) => {
    if (!date) return '';
    const [year, month] = date.split('-');
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    return `${monthNames[parseInt(month) - 1]} ${year}`;
  };

  const groupedSkills = skills.reduce((acc, skill) => {
    if (!acc[skill.category]) {
      acc[skill.category] = [];
    }
    acc[skill.category].push(skill);
    return acc;
  }, {} as Record<string, typeof skills>);

  return (
    <div 
      className="resume-creative bg-white min-h-[1056px] w-[816px] mx-auto shadow-lg flex"
      style={{ 
        fontFamily: customization.fontFamily,
        fontSize: customization.fontSize === 'small' ? '13px' : customization.fontSize === 'large' ? '17px' : '15px'
      }}
    >
      {/* Sidebar */}
      <aside 
        className="w-72 p-6 text-white"
        style={{ backgroundColor: customization.primaryColor }}
      >
        {/* Profile */}
        <div className="mb-8">
          <div 
            className="w-24 h-24 rounded-full mx-auto mb-4 flex items-center justify-center text-3xl font-bold"
            style={{ backgroundColor: customization.secondaryColor }}
          >
            {personalInfo.fullName?.split(' ').map(n => n[0]).join('') || 'YN'}
          </div>
          <h1 className="text-xl font-bold text-center mb-1">
            {personalInfo.fullName || 'Your Name'}
          </h1>
          {data.targetRole && (
            <p className="text-center text-sm opacity-90">{data.targetRole}</p>
          )}
        </div>

        {/* Contact */}
        <div className="mb-8">
          <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
            <span className="w-8 h-0.5 bg-white/50" />
            Contact
          </h2>
          <div className="space-y-2 text-sm">
            {personalInfo.email && (
              <div className="flex items-center gap-2">
                <Mail className="h-4 w-4 opacity-80" />
                <span className="break-all">{personalInfo.email}</span>
              </div>
            )}
            {personalInfo.phone && (
              <div className="flex items-center gap-2">
                <Phone className="h-4 w-4 opacity-80" />
                <span>{personalInfo.phone}</span>
              </div>
            )}
            {personalInfo.location && (
              <div className="flex items-center gap-2">
                <MapPin className="h-4 w-4 opacity-80" />
                <span>{personalInfo.location}</span>
              </div>
            )}
            {personalInfo.linkedin && (
              <div className="flex items-center gap-2">
                <Linkedin className="h-4 w-4 opacity-80" />
                <span className="break-all">{personalInfo.linkedin}</span>
              </div>
            )}
            {personalInfo.website && (
              <div className="flex items-center gap-2">
                <Globe className="h-4 w-4 opacity-80" />
                <span className="break-all">{personalInfo.website}</span>
              </div>
            )}
          </div>
        </div>

        {/* Skills */}
        {skills.length > 0 && (
          <div className="mb-8">
            <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-8 h-0.5 bg-white/50" />
              Skills
            </h2>
            <div className="space-y-3">
              {Object.entries(groupedSkills).map(([category, categorySkills]) => (
                <div key={category}>
                  <p className="text-xs opacity-80 mb-1">{category}</p>
                  <div className="flex flex-wrap gap-1">
                    {categorySkills.map((skill) => (
                      <span 
                        key={skill.id}
                        className="text-xs px-2 py-0.5 rounded-full"
                        style={{ backgroundColor: 'rgba(255,255,255,0.2)' }}
                      >
                        {skill.name}
                      </span>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Education in sidebar for creative */}
        {education.length > 0 && (
          <div>
            <h2 className="text-sm font-bold uppercase tracking-wider mb-3 flex items-center gap-2">
              <span className="w-8 h-0.5 bg-white/50" />
              Education
            </h2>
            <div className="space-y-3">
              {education.map((edu) => (
                <div key={edu.id}>
                  <p className="font-semibold text-sm">{edu.degree}</p>
                  <p className="text-xs opacity-90">{edu.field}</p>
                  <p className="text-xs opacity-80">{edu.institution}</p>
                  <p className="text-xs opacity-70">
                    {formatDate(edu.endDate)}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8">
        {/* Summary */}
        {personalInfo.summary && (
          <section className="mb-6">
            <h2 
              className="text-lg font-bold mb-2 flex items-center gap-2"
              style={{ color: customization.primaryColor }}
            >
              <Star className="h-5 w-5" />
              About Me
            </h2>
            <p className="text-gray-700 leading-relaxed">{personalInfo.summary}</p>
          </section>
        )}

        {/* Experience */}
        {experiences.length > 0 && (
          <section className="mb-6">
            <h2 
              className="text-lg font-bold mb-4 flex items-center gap-2"
              style={{ color: customization.primaryColor }}
            >
              <Briefcase className="h-5 w-5" />
              Experience
            </h2>
            <div className="space-y-4 relative">
              <div 
                className="absolute left-0 top-0 bottom-0 w-0.5"
                style={{ backgroundColor: customization.primaryColor, opacity: 0.3 }}
              />
              {experiences.map((exp) => (
                <div key={exp.id} className="pl-4 relative">
                  <div 
                    className="absolute left-0 top-1.5 w-2 h-2 rounded-full -translate-x-[3px]"
                    style={{ backgroundColor: customization.primaryColor }}
                  />
                  <div className="flex justify-between items-start mb-1">
                    <div>
                      <h3 className="font-semibold text-gray-900">{exp.position}</h3>
                      <p 
                        className="text-sm font-medium"
                        style={{ color: customization.primaryColor }}
                      >
                        {exp.company}
                      </p>
                    </div>
                    <span className="text-xs text-gray-500 bg-gray-100 px-2 py-0.5 rounded">
                      {formatDate(exp.startDate)} - {exp.current ? 'Present' : formatDate(exp.endDate)}
                    </span>
                  </div>
                  {exp.description && (
                    <p className="text-gray-600 text-sm mb-2">{exp.description}</p>
                  )}
                  {exp.achievements.filter(a => a).length > 0 && (
                    <ul className="text-sm text-gray-600 space-y-1">
                      {exp.achievements.filter(a => a).map((achievement, i) => (
                        <li key={i} className="flex items-start gap-2">
                          <span style={{ color: customization.primaryColor }}>▸</span>
                          {achievement}
                        </li>
                      ))}
                    </ul>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Projects */}
        {projects.length > 0 && (
          <section className="mb-6">
            <h2 
              className="text-lg font-bold mb-4 flex items-center gap-2"
              style={{ color: customization.primaryColor }}
            >
              <Code className="h-5 w-5" />
              Projects
            </h2>
            <div className="grid gap-3">
              {projects.map((project) => (
                <div 
                  key={project.id}
                  className="p-3 rounded-lg border"
                  style={{ borderColor: `${customization.primaryColor}30` }}
                >
                  <h3 className="font-semibold text-gray-900">{project.name}</h3>
                  <p className="text-gray-600 text-sm mt-1">{project.description}</p>
                  {project.technologies.length > 0 && (
                    <div className="flex flex-wrap gap-1 mt-2">
                      {project.technologies.map((tech, i) => (
                        <span 
                          key={i}
                          className="text-xs px-2 py-0.5 rounded"
                          style={{ 
                            backgroundColor: `${customization.primaryColor}15`,
                            color: customization.primaryColor
                          }}
                        >
                          {tech}
                        </span>
                      ))}
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>
        )}

        {/* Certifications */}
        {certifications.length > 0 && (
          <section className="mb-6">
            <h2 
              className="text-lg font-bold mb-3 flex items-center gap-2"
              style={{ color: customization.primaryColor }}
            >
              <Award className="h-5 w-5" />
              Certifications
            </h2>
            <div className="space-y-2">
              {certifications.map((cert) => (
                <div key={cert.id} className="flex justify-between items-center text-sm">
                  <div>
                    <span className="font-medium text-gray-900">{cert.name}</span>
                    <span className="text-gray-600"> – {cert.issuer}</span>
                  </div>
                  <span className="text-gray-500">{formatDate(cert.date)}</span>
                </div>
              ))}
            </div>
          </section>
        )}

        {/* References */}
        {references.length > 0 && (
          <section>
            <h2 
              className="text-lg font-bold mb-3 flex items-center gap-2"
              style={{ color: customization.primaryColor }}
            >
              <Users className="h-5 w-5" />
              References
            </h2>
            <div className="grid gap-3">
              {references.map((ref) => (
                <div 
                  key={ref.id}
                  className="p-3 rounded-lg border text-sm"
                  style={{ borderColor: `${customization.primaryColor}30` }}
                >
                  <p className="font-semibold text-gray-900">{ref.name}</p>
                  <p 
                    className="text-sm font-medium"
                    style={{ color: customization.primaryColor }}
                  >
                    {ref.title} at {ref.company}
                  </p>
                  <p className="text-gray-500 text-xs mt-1">{ref.relationship}</p>
                  <div className="mt-2 text-gray-600">
                    <p>{ref.email}</p>
                    {ref.phone && <p>{ref.phone}</p>}
                  </div>
                </div>
              ))}
            </div>
          </section>
        )}
      </main>
    </div>
  );
}
