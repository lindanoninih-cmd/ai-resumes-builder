import { ResumeData, TemplateCustomization } from '@/types/resume';

interface TemplateProps {
  data: ResumeData;
  customization: TemplateCustomization;
}

export function ClassicTemplate({ data, customization }: TemplateProps) {
  const { personalInfo, experiences, education, skills, projects, certifications, references } = data;

  const formatDate = (date: string) => {
    if (!date) return '';
    const [year, month] = date.split('-');
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    return `${monthNames[parseInt(month) - 1]} ${year}`;
  };

  return (
    <div 
      className="resume-classic bg-white p-10 min-h-[1056px] w-[816px] mx-auto shadow-lg"
      style={{ 
        fontFamily: "'Times New Roman', serif",
        fontSize: customization.fontSize === 'small' ? '14px' : customization.fontSize === 'large' ? '18px' : '16px'
      }}
    >
      {/* Header */}
      <header className="text-center mb-6 border-b border-gray-400 pb-4">
        <h1 className="text-3xl font-bold text-gray-900 uppercase tracking-wider mb-2">
          {personalInfo.fullName || 'Your Name'}
        </h1>
        
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm text-gray-700">
          {personalInfo.email && <span>{personalInfo.email}</span>}
          {personalInfo.phone && <span>| {personalInfo.phone}</span>}
          {personalInfo.location && <span>| {personalInfo.location}</span>}
        </div>
        <div className="flex flex-wrap justify-center gap-x-4 gap-y-1 text-sm text-gray-600 mt-1">
          {personalInfo.linkedin && <span>{personalInfo.linkedin}</span>}
          {personalInfo.website && <span>| {personalInfo.website}</span>}
        </div>
      </header>

      {/* Objective/Summary */}
      {personalInfo.summary && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-2">
            Objective
          </h2>
          <p className="text-gray-700 leading-relaxed text-justify">{personalInfo.summary}</p>
        </section>
      )}

      {/* Experience */}
      {experiences.length > 0 && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            Professional Experience
          </h2>
          <div className="space-y-4">
            {experiences.map((exp) => (
              <div key={exp.id}>
                <div className="flex justify-between items-baseline mb-1">
                  <h3 className="font-bold text-gray-900">{exp.company}</h3>
                  <span className="text-sm text-gray-600 italic">
                    {formatDate(exp.startDate)} – {exp.current ? 'Present' : formatDate(exp.endDate)}
                  </span>
                </div>
                <p className="italic text-gray-700 mb-1">{exp.position}{exp.location && `, ${exp.location}`}</p>
                {exp.description && (
                  <p className="text-gray-700 text-sm mb-2">{exp.description}</p>
                )}
                {exp.achievements.filter(a => a).length > 0 && (
                  <ul className="list-disc ml-5 text-sm text-gray-700 space-y-1">
                    {exp.achievements.filter(a => a).map((achievement, i) => (
                      <li key={i}>{achievement}</li>
                    ))}
                  </ul>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Education */}
      {education.length > 0 && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            Education
          </h2>
          <div className="space-y-3">
            {education.map((edu) => (
              <div key={edu.id}>
                <div className="flex justify-between items-baseline">
                  <h3 className="font-bold text-gray-900">{edu.institution}</h3>
                  <span className="text-sm text-gray-600 italic">
                    {formatDate(edu.startDate)} – {formatDate(edu.endDate)}
                  </span>
                </div>
                <p className="italic text-gray-700">
                  {edu.degree} in {edu.field}
                  {edu.location && `, ${edu.location}`}
                </p>
                {edu.gpa && <p className="text-sm text-gray-600">GPA: {edu.gpa}</p>}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Skills */}
      {skills.length > 0 && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            Skills
          </h2>
          <div className="text-gray-700">
            {skills.map((skill, index) => (
              <span key={skill.id}>
                {skill.name}
                {index < skills.length - 1 && ' • '}
              </span>
            ))}
          </div>
        </section>
      )}

      {/* Projects */}
      {projects.length > 0 && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            Projects
          </h2>
          <div className="space-y-3">
            {projects.map((project) => (
              <div key={project.id}>
                <h3 className="font-bold text-gray-900">{project.name}</h3>
                <p className="text-gray-700 text-sm">{project.description}</p>
                {project.technologies.length > 0 && (
                  <p className="text-sm italic text-gray-600 mt-1">
                    Technologies: {project.technologies.join(', ')}
                  </p>
                )}
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Certifications */}
      {certifications.length > 0 && (
        <section className="mb-5">
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            Certifications
          </h2>
          <ul className="space-y-1">
            {certifications.map((cert) => (
              <li key={cert.id} className="text-gray-700">
                <span className="font-semibold">{cert.name}</span>, {cert.issuer} ({formatDate(cert.date)})
              </li>
            ))}
          </ul>
        </section>
      )}

      {/* References */}
      {references.length > 0 && (
        <section>
          <h2 className="text-lg font-bold text-gray-900 uppercase border-b border-gray-300 mb-3">
            References
          </h2>
          <div className="grid grid-cols-2 gap-4">
            {references.map((ref) => (
              <div key={ref.id} className="text-gray-700">
                <p className="font-semibold">{ref.name}</p>
                <p className="italic">{ref.title}, {ref.company}</p>
                <p className="text-sm">{ref.relationship}</p>
                <p className="text-sm mt-1">{ref.email}</p>
                {ref.phone && <p className="text-sm">{ref.phone}</p>}
              </div>
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
