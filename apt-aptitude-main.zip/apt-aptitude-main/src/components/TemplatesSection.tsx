import { Check } from 'lucide-react';
import { Button } from './ui/button';

const templates = [
  {
    id: 'modern',
    name: 'Modern',
    description: 'Clean lines with a contemporary feel, perfect for tech and creative roles.',
    features: ['Two-column layout', 'Accent color sidebar', 'Progress bars for skills'],
  },
  {
    id: 'classic',
    name: 'Classic',
    description: 'Timeless and professional, ideal for traditional industries.',
    features: ['Single-column layout', 'Clear section headers', 'Formal typography'],
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Bold and distinctive, designed to make you stand out.',
    features: ['Sidebar design', 'Visual skill indicators', 'Modern typography'],
  },
];

interface TemplatesSectionProps {
  onGetStarted?: () => void;
}

export function TemplatesSection({ onGetStarted }: TemplatesSectionProps) {
  return (
    <section id="templates" className="py-20 bg-muted/30">
      <div className="container">
        <div className="text-center mb-12">
          <h2 className="text-3xl font-bold mb-4">Choose Your Template</h2>
          <p className="text-muted-foreground max-w-2xl mx-auto">
            Start with a professionally designed template and customize it to match your style
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {templates.map((template) => (
            <div
              key={template.id}
              className="bg-card rounded-xl border border-border overflow-hidden hover:shadow-lg transition-shadow"
            >
              {/* Template Preview */}
              <div className="aspect-[8.5/11] bg-background p-4 border-b border-border">
                {template.id === 'modern' && (
                  <div className="h-full flex text-[6px]">
                    <div className="w-1/3 bg-primary/10 p-2 space-y-2">
                      <div className="w-8 h-8 rounded-full bg-primary/30 mx-auto" />
                      <div className="h-1.5 bg-primary/40 rounded w-full" />
                      <div className="h-1 bg-muted rounded w-3/4" />
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="mt-3 space-y-1">
                        <div className="h-1 bg-primary/30 rounded" />
                        <div className="h-0.5 bg-muted rounded w-4/5" />
                      </div>
                    </div>
                    <div className="flex-1 p-2 space-y-2">
                      <div className="h-2 bg-foreground/20 rounded w-3/4" />
                      <div className="h-1 bg-muted rounded w-1/2" />
                      <div className="mt-3 space-y-1">
                        <div className="h-1.5 bg-primary/30 rounded w-1/3" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-5/6" />
                        <div className="h-1 bg-muted rounded w-4/5" />
                      </div>
                      <div className="mt-3 space-y-1">
                        <div className="h-1.5 bg-primary/30 rounded w-1/4" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-3/4" />
                      </div>
                    </div>
                  </div>
                )}
                {template.id === 'classic' && (
                  <div className="h-full p-2 space-y-2 text-[6px]">
                    <div className="text-center space-y-1 pb-2 border-b border-border">
                      <div className="h-2.5 bg-foreground/20 rounded w-1/2 mx-auto" />
                      <div className="h-1 bg-muted rounded w-2/3 mx-auto" />
                    </div>
                    <div className="space-y-1.5">
                      <div className="h-1.5 bg-primary/40 rounded w-1/4" />
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="h-1 bg-muted rounded w-5/6" />
                    </div>
                    <div className="space-y-1.5">
                      <div className="h-1.5 bg-primary/40 rounded w-1/3" />
                      <div className="flex gap-1">
                        <div className="h-1.5 bg-foreground/15 rounded w-1/4" />
                        <div className="h-1 bg-muted/60 rounded w-1/5" />
                      </div>
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="h-1 bg-muted rounded w-4/5" />
                    </div>
                    <div className="space-y-1.5">
                      <div className="h-1.5 bg-primary/40 rounded w-1/4" />
                      <div className="h-1 bg-muted rounded w-3/4" />
                      <div className="h-1 bg-muted rounded w-2/3" />
                    </div>
                  </div>
                )}
                {template.id === 'creative' && (
                  <div className="h-full flex text-[6px]">
                    <div className="w-2/5 bg-primary p-2 space-y-2">
                      <div className="w-10 h-10 rounded-full bg-primary-foreground/30 mx-auto" />
                      <div className="h-2 bg-primary-foreground/80 rounded w-3/4 mx-auto" />
                      <div className="h-1 bg-primary-foreground/50 rounded w-full" />
                      <div className="mt-2 space-y-1">
                        <div className="h-1 bg-primary-foreground/60 rounded w-1/2" />
                        <div className="h-0.5 bg-primary-foreground/30 rounded w-full" />
                        <div className="h-0.5 bg-primary-foreground/30 rounded w-4/5" />
                      </div>
                      <div className="mt-2 space-y-1">
                        <div className="h-1 bg-primary-foreground/60 rounded w-1/3" />
                        <div className="flex gap-0.5">
                          <div className="h-1.5 flex-1 bg-primary-foreground/40 rounded" />
                          <div className="h-1.5 flex-1 bg-primary-foreground/40 rounded" />
                        </div>
                      </div>
                    </div>
                    <div className="flex-1 p-2 space-y-2">
                      <div className="space-y-1">
                        <div className="h-1.5 bg-primary/50 rounded w-1/3" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-5/6" />
                      </div>
                      <div className="space-y-1">
                        <div className="h-1.5 bg-primary/50 rounded w-1/4" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-3/4" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Template Info */}
              <div className="p-6">
                <h3 className="text-xl font-semibold mb-2">{template.name}</h3>
                <p className="text-sm text-muted-foreground mb-4">{template.description}</p>
                <ul className="space-y-2 mb-6">
                  {template.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-sm">
                      <Check className="h-4 w-4 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  variant="outline" 
                  className="w-full"
                  onClick={onGetStarted}
                >
                  Use This Template
                </Button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
