import { useState } from 'react';
import { useResume } from '@/contexts/ResumeContext';
import { Button } from '@/components/ui/button';
import { PersonalInfoForm } from './forms/PersonalInfoForm';
import { ExperienceForm } from './forms/ExperienceForm';
import { EducationForm } from './forms/EducationForm';
import { SkillsForm } from './forms/SkillsForm';
import { TargetRoleForm } from './forms/TargetRoleForm';
import { ReferencesForm } from './forms/ReferencesForm';
import { TemplateSelector } from './TemplateSelector';
import { ResumePreview } from './ResumePreview';
import { ATSScoreCard } from './ATSScoreCard';
import { JobMatchAnalysis } from './JobMatchAnalysis';
import { StepIndicator } from './StepIndicator';
import { ChevronLeft, ChevronRight, Sparkles } from 'lucide-react';

const steps = [
  { id: 1, name: 'Personal Info', description: 'Contact details' },
  { id: 2, name: 'Experience', description: 'Work history' },
  { id: 3, name: 'Education', description: 'Academic background' },
  { id: 4, name: 'Skills', description: 'Your abilities' },
  { id: 5, name: 'References', description: 'Professional references' },
  { id: 6, name: 'Target Role', description: 'Job preferences' },
  { id: 7, name: 'Customize', description: 'Template & style' },
];

export function ResumeBuilder() {
  const { currentStep, setCurrentStep } = useResume();

  const renderStepContent = () => {
    switch (currentStep) {
      case 0:
        return <PersonalInfoForm />;
      case 1:
        return <ExperienceForm />;
      case 2:
        return <EducationForm />;
      case 3:
        return <SkillsForm />;
      case 4:
        return <ReferencesForm />;
      case 5:
        return <TargetRoleForm />;
      case 6:
        return (
          <div className="space-y-6">
            <TemplateSelector />
            <ATSScoreCard />
            <JobMatchAnalysis />
          </div>
        );
      default:
        return <PersonalInfoForm />;
    }
  };

  return (
    <section className="py-12 bg-background">
      <div className="container">
        <div className="text-center mb-8">
          <h2 className="text-3xl font-bold mb-2">Build Your Resume</h2>
          <p className="text-muted-foreground">
            Follow the steps below to create your professional resume
          </p>
        </div>

        <StepIndicator 
          steps={steps} 
          currentStep={currentStep}
          onStepClick={setCurrentStep}
        />

        <div className="grid lg:grid-cols-2 gap-8">
          {/* Form Section */}
          <div className="space-y-6">
            {renderStepContent()}

            {/* Navigation */}
            <div className="flex justify-between pt-4">
              <Button
                variant="outline"
                onClick={() => setCurrentStep(Math.max(0, currentStep - 1))}
                disabled={currentStep === 0}
                className="gap-2"
              >
                <ChevronLeft className="h-4 w-4" />
                Previous
              </Button>

              {currentStep < steps.length - 1 ? (
                <Button
                  onClick={() => setCurrentStep(Math.min(steps.length - 1, currentStep + 1))}
                  className="gap-2"
                >
                  Next
                  <ChevronRight className="h-4 w-4" />
                </Button>
              ) : (
                <Button variant="hero" className="gap-2">
                  <Sparkles className="h-4 w-4" />
                  Generate Resume
                </Button>
              )}
            </div>
          </div>

          {/* Preview Section */}
          <div className="lg:block hidden">
            <ResumePreview />
          </div>
        </div>

        {/* Mobile Preview */}
        <div className="lg:hidden mt-8">
          <ResumePreview />
        </div>
      </div>
    </section>
  );
}
