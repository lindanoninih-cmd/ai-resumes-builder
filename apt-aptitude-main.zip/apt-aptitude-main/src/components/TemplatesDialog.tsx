import { Check } from 'lucide-react';
import { Button } from './ui/button';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from './ui/dialog';

const templates = [
  {
    id: 'modern',
    name: 'Modern',
    description: 'Clean lines with a contemporary feel, perfect for tech and creative roles.',
    features: ['Two-column layout', 'Accent color sidebar', 'Progress bars for skills'],
  },
  {
    id: 'classic',
    name: 'Classic',
    description: 'Timeless and professional, ideal for traditional industries.',
    features: ['Single-column layout', 'Clear section headers', 'Formal typography'],
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Bold and distinctive, designed to make you stand out.',
    features: ['Sidebar design', 'Visual skill indicators', 'Modern typography'],
  },
];

interface TemplatesDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  onSelectTemplate: (templateId: string) => void;
}

export function TemplatesDialog({ open, onOpenChange, onSelectTemplate }: TemplatesDialogProps) {
  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-5xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle className="text-2xl font-bold text-center">Choose Your Template</DialogTitle>
        </DialogHeader>
        
        <div className="grid md:grid-cols-3 gap-6 mt-4">
          {templates.map((template) => (
            <div
              key={template.id}
              className="bg-card rounded-xl border border-border overflow-hidden hover:shadow-lg transition-all hover:border-primary/50"
            >
              {/* Template Preview */}
              <div className="aspect-[8.5/11] bg-background p-3 border-b border-border">
                {template.id === 'modern' && (
                  <div className="h-full flex text-[5px]">
                    <div className="w-1/3 bg-primary/10 p-2 space-y-2">
                      <div className="w-6 h-6 rounded-full bg-primary/30 mx-auto" />
                      <div className="h-1.5 bg-primary/40 rounded w-full" />
                      <div className="h-1 bg-muted rounded w-3/4" />
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="mt-2 space-y-1">
                        <div className="h-1 bg-primary/30 rounded" />
                        <div className="h-0.5 bg-muted rounded w-4/5" />
                      </div>
                    </div>
                    <div className="flex-1 p-2 space-y-2">
                      <div className="h-2 bg-foreground/20 rounded w-3/4" />
                      <div className="h-1 bg-muted rounded w-1/2" />
                      <div className="mt-2 space-y-1">
                        <div className="h-1.5 bg-primary/30 rounded w-1/3" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-5/6" />
                      </div>
                    </div>
                  </div>
                )}
                {template.id === 'classic' && (
                  <div className="h-full p-2 space-y-2 text-[5px]">
                    <div className="text-center space-y-1 pb-2 border-b border-border">
                      <div className="h-2 bg-foreground/20 rounded w-1/2 mx-auto" />
                      <div className="h-1 bg-muted rounded w-2/3 mx-auto" />
                    </div>
                    <div className="space-y-1">
                      <div className="h-1.5 bg-primary/40 rounded w-1/4" />
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="h-1 bg-muted rounded w-5/6" />
                    </div>
                    <div className="space-y-1">
                      <div className="h-1.5 bg-primary/40 rounded w-1/3" />
                      <div className="h-1 bg-muted rounded w-full" />
                      <div className="h-1 bg-muted rounded w-4/5" />
                    </div>
                  </div>
                )}
                {template.id === 'creative' && (
                  <div className="h-full flex text-[5px]">
                    <div className="w-2/5 bg-primary p-2 space-y-2">
                      <div className="w-8 h-8 rounded-full bg-primary-foreground/30 mx-auto" />
                      <div className="h-1.5 bg-primary-foreground/80 rounded w-3/4 mx-auto" />
                      <div className="h-1 bg-primary-foreground/50 rounded w-full" />
                      <div className="mt-2 space-y-1">
                        <div className="h-1 bg-primary-foreground/60 rounded w-1/2" />
                        <div className="h-0.5 bg-primary-foreground/30 rounded w-full" />
                      </div>
                    </div>
                    <div className="flex-1 p-2 space-y-2">
                      <div className="space-y-1">
                        <div className="h-1.5 bg-primary/50 rounded w-1/3" />
                        <div className="h-1 bg-muted rounded w-full" />
                        <div className="h-1 bg-muted rounded w-5/6" />
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Template Info */}
              <div className="p-4">
                <h3 className="text-lg font-semibold mb-1">{template.name}</h3>
                <p className="text-xs text-muted-foreground mb-3">{template.description}</p>
                <ul className="space-y-1 mb-4">
                  {template.features.map((feature, index) => (
                    <li key={index} className="flex items-center gap-2 text-xs">
                      <Check className="h-3 w-3 text-primary" />
                      <span>{feature}</span>
                    </li>
                  ))}
                </ul>
                <Button 
                  variant="default" 
                  size="sm"
                  className="w-full"
                  onClick={() => onSelectTemplate(template.id)}
                >
                  Use This Template
                </Button>
              </div>
            </div>
          ))}
        </div>
      </DialogContent>
    </Dialog>
  );
}
