import { useResume } from '@/contexts/ResumeContext';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { TemplateType } from '@/types/resume';
import { Palette, Check } from 'lucide-react';
import { cn } from '@/lib/utils';

const templates: { id: TemplateType; name: string; description: string }[] = [
  {
    id: 'modern',
    name: 'Modern',
    description: 'Clean and professional with accent colors',
  },
  {
    id: 'classic',
    name: 'Classic',
    description: 'Traditional format, perfect for conservative industries',
  },
  {
    id: 'creative',
    name: 'Creative',
    description: 'Bold sidebar design for creative roles',
  },
];

const colorPresets = [
  { name: 'Teal', primary: '#0d9488', secondary: '#14b8a6' },
  { name: 'Blue', primary: '#2563eb', secondary: '#3b82f6' },
  { name: 'Purple', primary: '#7c3aed', secondary: '#8b5cf6' },
  { name: 'Green', primary: '#16a34a', secondary: '#22c55e' },
  { name: 'Orange', primary: '#ea580c', secondary: '#f97316' },
  { name: 'Navy', primary: '#1e3a5f', secondary: '#2563eb' },
];

export function TemplateSelector() {
  const { selectedTemplate, setSelectedTemplate, customization, setCustomization } = useResume();

  return (
    <Card className="shadow-card">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <Palette className="h-5 w-5 text-primary" />
          Template & Style
        </CardTitle>
        <CardDescription>
          Choose a template and customize its appearance
        </CardDescription>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Template Selection */}
        <div className="space-y-3">
          <Label>Select Template</Label>
          <div className="grid grid-cols-3 gap-3">
            {templates.map((template) => (
              <button
                key={template.id}
                onClick={() => setSelectedTemplate(template.id)}
                className={cn(
                  'relative rounded-lg border-2 p-2 text-left transition-all hover:border-primary/50 overflow-hidden',
                  selectedTemplate === template.id
                    ? 'border-primary bg-accent'
                    : 'border-border'
                )}
              >
                {selectedTemplate === template.id && (
                  <div className="absolute -right-2 -top-2 rounded-full bg-primary p-1 z-10">
                    <Check className="h-3 w-3 text-primary-foreground" />
                  </div>
                )}
                {/* Template Preview Thumbnail */}
                <div className="aspect-[8.5/11] bg-white rounded border border-border/50 mb-2 overflow-hidden">
                  {template.id === 'modern' && (
                    <div className="h-full p-2 text-[4px] leading-tight">
                      <div className="text-center mb-1">
                        <div className="font-bold text-[6px] text-gray-800">John Doe</div>
                        <div className="text-gray-500">Software Engineer</div>
                        <div className="text-gray-400 flex justify-center gap-1">
                          <span>email@example.com</span>
                          <span>•</span>
                          <span>(555) 123-4567</span>
                        </div>
                      </div>
                      <div className="h-[1px] bg-teal-500 my-1" />
                      <div className="mb-1">
                        <div className="font-semibold text-teal-600 border-b border-teal-200 mb-0.5">Experience</div>
                        <div className="font-medium text-gray-700">Senior Developer</div>
                        <div className="text-gray-500">Tech Company • 2020-Present</div>
                        <div className="text-gray-400">• Led development team...</div>
                      </div>
                      <div>
                        <div className="font-semibold text-teal-600 border-b border-teal-200 mb-0.5">Education</div>
                        <div className="font-medium text-gray-700">BS Computer Science</div>
                        <div className="text-gray-500">University • 2016</div>
                      </div>
                    </div>
                  )}
                  {template.id === 'classic' && (
                    <div className="h-full p-2 text-[4px] leading-tight">
                      <div className="text-center mb-1 border-b-2 border-gray-800 pb-1">
                        <div className="font-bold text-[7px] text-gray-900 uppercase tracking-wide">John Doe</div>
                        <div className="text-gray-600">123 Main St • City, ST 12345</div>
                        <div className="text-gray-600">email@example.com • (555) 123-4567</div>
                      </div>
                      <div className="mb-1">
                        <div className="font-bold text-gray-900 uppercase border-b border-gray-400 mb-0.5">Professional Experience</div>
                        <div className="flex justify-between">
                          <span className="font-semibold">Senior Developer</span>
                          <span className="text-gray-600">2020-Present</span>
                        </div>
                        <div className="italic text-gray-600">Tech Company, City</div>
                        <div className="text-gray-700">• Managed development projects...</div>
                      </div>
                      <div>
                        <div className="font-bold text-gray-900 uppercase border-b border-gray-400 mb-0.5">Education</div>
                        <div className="font-semibold">Bachelor of Science</div>
                        <div className="text-gray-600">University Name, 2016</div>
                      </div>
                    </div>
                  )}
                  {template.id === 'creative' && (
                    <div className="h-full flex text-[4px] leading-tight">
                      <div className="w-1/3 bg-purple-700 text-white p-1.5">
                        <div className="w-4 h-4 rounded-full bg-purple-400 mx-auto mb-1" />
                        <div className="font-bold text-[5px] text-center">John Doe</div>
                        <div className="text-purple-200 text-center mb-1">Developer</div>
                        <div className="text-[3px] space-y-0.5">
                          <div className="font-semibold text-purple-300">Contact</div>
                          <div>email@example.com</div>
                          <div>(555) 123-4567</div>
                          <div className="font-semibold text-purple-300 mt-1">Skills</div>
                          <div>JavaScript</div>
                          <div>React</div>
                          <div>Node.js</div>
                        </div>
                      </div>
                      <div className="flex-1 p-1.5 bg-white">
                        <div className="mb-1">
                          <div className="font-bold text-purple-700 border-b border-purple-200 mb-0.5">Experience</div>
                          <div className="font-semibold">Senior Developer</div>
                          <div className="text-gray-500">Tech Co • 2020-Now</div>
                          <div className="text-gray-600">• Led team projects</div>
                        </div>
                        <div>
                          <div className="font-bold text-purple-700 border-b border-purple-200 mb-0.5">Education</div>
                          <div className="font-semibold">BS Computer Sci</div>
                          <div className="text-gray-500">University • 2016</div>
                        </div>
                      </div>
                    </div>
                  )}
                </div>
                <div className="font-semibold text-sm">{template.name}</div>
                <div className="text-xs text-muted-foreground">
                  {template.description}
                </div>
              </button>
            ))}
          </div>
        </div>

        {/* Color Presets */}
        <div className="space-y-3">
          <Label>Color Theme</Label>
          <div className="flex flex-wrap gap-2">
            {colorPresets.map((preset) => (
              <button
                key={preset.name}
                onClick={() =>
                  setCustomization((prev) => ({
                    ...prev,
                    primaryColor: preset.primary,
                    secondaryColor: preset.secondary,
                  }))
                }
                className={cn(
                  'flex items-center gap-2 rounded-full border px-3 py-1.5 text-sm transition-all',
                  customization.primaryColor === preset.primary
                    ? 'border-primary bg-accent'
                    : 'border-border hover:border-primary/50'
                )}
              >
                <div
                  className="h-4 w-4 rounded-full"
                  style={{ backgroundColor: preset.primary }}
                />
                {preset.name}
              </button>
            ))}
          </div>
        </div>

        {/* Custom Colors */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Primary Color</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={customization.primaryColor}
                onChange={(e) =>
                  setCustomization((prev) => ({
                    ...prev,
                    primaryColor: e.target.value,
                  }))
                }
                className="h-10 w-14 p-1 cursor-pointer"
              />
              <Input
                value={customization.primaryColor}
                onChange={(e) =>
                  setCustomization((prev) => ({
                    ...prev,
                    primaryColor: e.target.value,
                  }))
                }
                className="flex-1"
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>Secondary Color</Label>
            <div className="flex gap-2">
              <Input
                type="color"
                value={customization.secondaryColor}
                onChange={(e) =>
                  setCustomization((prev) => ({
                    ...prev,
                    secondaryColor: e.target.value,
                  }))
                }
                className="h-10 w-14 p-1 cursor-pointer"
              />
              <Input
                value={customization.secondaryColor}
                onChange={(e) =>
                  setCustomization((prev) => ({
                    ...prev,
                    secondaryColor: e.target.value,
                  }))
                }
                className="flex-1"
              />
            </div>
          </div>
        </div>

        {/* Typography */}
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-2">
            <Label>Font Size</Label>
            <Select
              value={customization.fontSize}
              onValueChange={(value: 'small' | 'medium' | 'large') =>
                setCustomization((prev) => ({ ...prev, fontSize: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="small">Small</SelectItem>
                <SelectItem value="medium">Medium</SelectItem>
                <SelectItem value="large">Large</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>Spacing</Label>
            <Select
              value={customization.spacing}
              onValueChange={(value: 'compact' | 'normal' | 'relaxed') =>
                setCustomization((prev) => ({ ...prev, spacing: value }))
              }
            >
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="compact">Compact</SelectItem>
                <SelectItem value="normal">Normal</SelectItem>
                <SelectItem value="relaxed">Relaxed</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
