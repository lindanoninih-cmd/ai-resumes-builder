import React, { createContext, useContext, useState, ReactNode } from 'react';
import { 
  ResumeData, 
  TemplateType, 
  TemplateCustomization, 
  ATSScore, 
  JobMatch,
  ContentSuggestion 
} from '@/types/resume';

interface ResumeContextType {
  resumeData: ResumeData;
  setResumeData: React.Dispatch<React.SetStateAction<ResumeData>>;
  selectedTemplate: TemplateType;
  setSelectedTemplate: React.Dispatch<React.SetStateAction<TemplateType>>;
  customization: TemplateCustomization;
  setCustomization: React.Dispatch<React.SetStateAction<TemplateCustomization>>;
  atsScore: ATSScore | null;
  setAtsScore: React.Dispatch<React.SetStateAction<ATSScore | null>>;
  jobMatch: JobMatch | null;
  setJobMatch: React.Dispatch<React.SetStateAction<JobMatch | null>>;
  jobDescription: string;
  setJobDescription: React.Dispatch<React.SetStateAction<string>>;
  suggestions: ContentSuggestion[];
  setSuggestions: React.Dispatch<React.SetStateAction<ContentSuggestion[]>>;
  isGenerating: boolean;
  setIsGenerating: React.Dispatch<React.SetStateAction<boolean>>;
  currentStep: number;
  setCurrentStep: React.Dispatch<React.SetStateAction<number>>;
}

const defaultResumeData: ResumeData = {
  personalInfo: {
    fullName: '',
    email: '',
    phone: '',
    location: '',
    linkedin: '',
    website: '',
    summary: '',
  },
  experiences: [],
  education: [],
  skills: [],
  projects: [],
  certifications: [],
  references: [],
  targetRole: '',
  targetIndustry: '',
};

const defaultCustomization: TemplateCustomization = {
  primaryColor: '#0d9488',
  secondaryColor: '#14b8a6',
  fontFamily: 'Plus Jakarta Sans',
  fontSize: 'medium',
  spacing: 'normal',
};

const ResumeContext = createContext<ResumeContextType | undefined>(undefined);

export function ResumeProvider({ children }: { children: ReactNode }) {
  const [resumeData, setResumeData] = useState<ResumeData>(defaultResumeData);
  const [selectedTemplate, setSelectedTemplate] = useState<TemplateType>('modern');
  const [customization, setCustomization] = useState<TemplateCustomization>(defaultCustomization);
  const [atsScore, setAtsScore] = useState<ATSScore | null>(null);
  const [jobMatch, setJobMatch] = useState<JobMatch | null>(null);
  const [jobDescription, setJobDescription] = useState('');
  const [suggestions, setSuggestions] = useState<ContentSuggestion[]>([]);
  const [isGenerating, setIsGenerating] = useState(false);
  const [currentStep, setCurrentStep] = useState(0);

  return (
    <ResumeContext.Provider
      value={{
        resumeData,
        setResumeData,
        selectedTemplate,
        setSelectedTemplate,
        customization,
        setCustomization,
        atsScore,
        setAtsScore,
        jobMatch,
        setJobMatch,
        jobDescription,
        setJobDescription,
        suggestions,
        setSuggestions,
        isGenerating,
        setIsGenerating,
        currentStep,
        setCurrentStep,
      }}
    >
      {children}
    </ResumeContext.Provider>
  );
}

export function useResume() {
  const context = useContext(ResumeContext);
  if (context === undefined) {
    throw new Error('useResume must be used within a ResumeProvider');
  }
  return context;
}
